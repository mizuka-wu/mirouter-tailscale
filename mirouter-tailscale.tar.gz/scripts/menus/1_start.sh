# 启动服务

start_service() {
    # 检查是否已运行
    if pidof tailscaled >/dev/null 2>&1; then
        msg_alert "\033[33mTailscale 已在运行 (PID: $(pidof tailscaled | awk '{print $NF}'))\033[0m"
        return 0
    fi

    # 检查 Auth Key
    if [ -z "$auth_key" ]; then
        comp_box "\033[31m未配置 Auth Key！\033[0m" \
            "请先在 [2] 设置 中配置 Auth Key"
        return 1
    fi

    comp_box "\033[36m正在启动 Tailscale ...\033[0m"

    # 确保目录存在
    mkdir -p "$TMP_DIR" "$STATE_DIR"

    # 检查二进制文件
    if [ ! -x "$BIN_TSD" ]; then
        content_line "\033[33m内存中无二进制文件，正在下载...\033[0m"
        separator_line "-"
        if ! download_binary; then
            comp_box "\033[31m下载失败！\033[0m" \
                "请检查下载源或网络连接" \
                "可在 [2] 设置 中配置局域网下载源"
            return 1
        fi
    fi

    # 启动 tailscaled
    "$BIN_TSD" \
        -state "$STATE_FILE" \
        --tun=userspace-networking \
        --socks5-server=localhost:"$socks_port" \
        --outbound-http-proxy-listen=localhost:"$socks_port" \
        >/dev/null 2>&1 &

    # 等待就绪
    content_line "等待 tailscaled 就绪..."
    local i=0
    while [ $i -lt 20 ]; do
        "$BIN_TS" status >/dev/null 2>&1 && break
        sleep 1
        i=$((i+1))
    done

    if ! pidof tailscaled >/dev/null 2>&1; then
        comp_box "\033[31m启动失败！\033[0m" \
            "请检查日志: $TMP_DIR/ts.log"
        return 1
    fi

    # 执行上线
    ts_up

    local PID=$(pidof tailscaled | awk '{print $NF}')
    comp_box "\033[32mTailscale 已启动\033[0m" \
        "PID: $PID" \
        "SOCKS5 代理: localhost:$socks_port"

    # 确保 cron 守护已配置
    setup_monitor_cron

    return 0
}

# 下载二进制文件 (多镜像 fallback)
download_binary() {
    mkdir -p "$TMP_DIR"

    # 尝试多镜像下载
    ts_download "$TMP_DIR/tailscale.tgz" "$TS_PKG_MIRRORS"
    if [ "$result" != "200" ]; then
        return 1
    fi

    content_line "下载完成，正在解压..."
    cd "$TMP_DIR" || return 1
    tar zxf tailscale.tgz >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        rm -f tailscale.tgz
        return 1
    fi

    local local_dir="tailscale_${ts_version}_${arch}"
    mv "$local_dir/tailscale" "$TMP_DIR/" 2>/dev/null
    mv "$local_dir/tailscaled" "$TMP_DIR/" 2>/dev/null
    chmod +x "$BIN_TS" "$BIN_TSD"
    rm -rf tailscale.tgz "$local_dir"

    [ -x "$BIN_TSD" ] && return 0 || return 1
}

# 执行 tailscale up
ts_up() {
    local UP_ARGS="--timeout=20s"
    [ -n "$auth_key" ] && UP_ARGS="$UP_ARGS --authkey=$auth_key"
    UP_ARGS="$UP_ARGS --accept-dns=$accept_dns"
    UP_ARGS="$UP_ARGS --snat-subnet-routes=$snat_subnet"
    [ -n "$routes" ] && UP_ARGS="$UP_ARGS --advertise-routes=$routes"
    [ "$use_exit_node" = "ON" ] && UP_ARGS="$UP_ARGS --advertise-exit-node"

    # shellcheck disable=SC2086
    "$BIN_TS" up $UP_ARGS >/dev/null 2>&1
}

# 设置监控 cron
setup_monitor_cron() {
    local monitor="$TSDIR/scripts/starts/monitor.sh"
    if [ -x "$monitor" ]; then
        cronset "ts_monitor" "* * * * * $monitor >/dev/null 2>&1 #ts_monitor"
        content_line "\033[32m已配置 cron 守护 (每分钟巡检)\033[0m"
    fi
}
